@extends('web.v2.layout.base')

@section('nav.about')
	active
@endsection

@section('pages')
	<!-- <section id="breadcrumb">
		<div class="vertical-center sun">
		</div>
   </section> -->
   <div class="clearfix">&nbsp;</div>
   <div class="clearfix">&nbsp;</div>
   <div class="clearfix">&nbsp;</div>
   <!-- Service Section -->
	<section id="services" class="section services">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-6">
					<img src="https://scontent-sin6-1.cdninstagram.com/vp/799c8efb884a8dbe4578f41a3f2e951b/5C646FCB/t51.2885-15/e35/25014619_1526002317507916_8154566809610092544_n.jpg" class="img-responsive" alt=""> </a> 
				</div>
				<div class="col-md-6">
					<div class="services-content">
						<h1 style="font-family: 'Sacramento', cursive;font-size:7rem" class="text-red">Meet</h1>
						<h4 style="font-family: 'Sacramento', cursive;font-size:4rem">Febri Kristiawan</h4>
						<p>
							Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sit amet sodales dui, eget feugiat lacus. Donec tempus porta diam, eget mollis sem posuere in. Vestibulum dictum ligula dolor, sed vestibulum ligula fermentum id. Nulla suscipit enim ac nulla vestibulum mollis. Duis vel ornare tortor, quis porttitor nulla. Fusce fringilla, turpis sit amet consectetur commodo, lorem velit bibendum leo, elementum vehicula sem lorem sit amet ipsum. Etiam mattis at mauris a porttitor.
						</p>
					</div>
				</div>
			</div>
		    <div class="clearfix">&nbsp;</div>
		    <div class="clearfix">&nbsp;</div>
		    <div class="clearfix">&nbsp;</div>
		    <div class="clearfix">&nbsp;</div>
			<div class="row">
				<div class="col-md-6">
					<div class="services-content">
						<h1 style="font-family: 'Sacramento', cursive;font-size:7rem" class="text-red">And</h1>
						<h4 style="font-family: 'Sacramento', cursive;font-size:4rem">Ronny Sugiarto</h4>
						<p>
							Sed quis ex turpis. Mauris vestibulum mauris in neque tempor mollis. Etiam molestie libero nec elit ornare, et varius ex eleifend. Aliquam erat volutpat. Ut vitae diam fringilla, aliquam mi eu, hendrerit lacus. Fusce dignissim id metus in ultrices. Sed tincidunt posuere risus ut malesuada. In hac habitasse platea dictumst. Vestibulum tincidunt tincidunt urna aliquet ullamcorper. Mauris in magna massa.
						</p>
					</div>
				</div>
				<div class="col-md-6">
					<img src="https://scontent-sin6-1.cdninstagram.com/vp/fe360f33bbabb0ade662dd0a0624dbf5/5C547F55/t51.2885-15/e35/25022030_1854691181489136_921966523097022464_n.jpg" class="img-responsive" alt=""> </a> 
				</div>
			</div>
		</div>
	</section>
	<!-- Service Section --> 
@endsection
